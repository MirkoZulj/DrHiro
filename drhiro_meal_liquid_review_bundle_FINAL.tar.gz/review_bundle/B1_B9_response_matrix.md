# B1-B9 Response Matrix

## B1 — Nutrient Resolution (CLOSED)
- **Affected path**: `consumption.py` `resolve_item_nutrition()`
- **Reproducer**: Draft handler stored empty nutrients to Redis.
- **Fix**: Real resolution path (DB → external), scaling, provenance.
- **Verification**: `test_stage2_b1_b8_regression.py` (25 tests).
- **Closed in**: Stage 2 (cbc01e0)

## B2 — Durable Replay Without Redis Draft (CLOSED)
- **Affected path**: `consumption.py` `find_completed_result_by_identity()`
- **Fix**: `find_completed_result_by_identity()` + rewritten `confirm_meal`.
- **Verification**: `test_consumption_confirm_integration.py::TestB2DurableReplayWithoutDraft` (3 tests).
- **Closed in**: Stage 1

## B3 — Trusted Identity Propagation (CLOSED)
- **Affected path**: `consumption.py` `get_or_create_operation`, `ConsumptionOperation.payload_hash`
- **Fix**: Fail-closed identity enforcement + `payload_hash`.
- **Verification**: `test_b3_identity_propagation.py` (21 tests).
- **Closed in**: Stage 1

## B4 — Entry-Point Coverage (CLOSED)
- **Affected path**: `routers/meals.py` + `routers/datapoints.py`
- **Fix**: Wire add_meal_item, copy_meal, patch_meal_item, remove_meal_item, delete_meal, update_data_point, delete_data_point.
- **Verification**: `test_stage3_b4_b7_regression.py` (4 tests) + `test_stage3_wired_paths.py` (25 tests).
- **Closed in**: Stage 3 (76c6e4f)

## B5 — Concurrency-Safe First Creation (CLOSED)
- **Affected path**: `consumption.py` `get_or_create_operation` atomic INSERT
- **Fix**: `INSERT ... ON CONFLICT DO NOTHING` + re-select winner.
- **Verification**: `test_b5_concurrent.py` (genuine concurrent test).
- **Closed in**: Stage 1

## B6 — Migration Single Authority (CLOSED)
- **Affected path**: Alembic revision `f1a2b3c4d5e6_consumption_idempotency.py`
- **Fix**: One Alembic revision as single authority.
- **Verification**: `test_b6_migration_authority.py` (13 tests).
- **Closed in**: Stage 1

## B7 — Canonical Atomic Mutations (CLOSED)
- **Affected path**: `consumption.py` (delete_meal cascade + beverage→solid rename)
- **Fix**: Eager cascade in delete_meal; `_classify_beverage` as source of truth.
- **Verification**: `test_b7_closing_regression.py` (7 tests) + `test_stage3_b4_b7_regression.py` (8 tests).
- **Closed in**: Stage 3 (febc798)

## B8 — Parser Conversions/Classification (CLOSED)
- **Affected path**: `consumption.py` `parse_consumption_text()`
- **Fix**: Added `dl`, `dcl`, `cl`, plurals to `_VOLUME_UNITS`; prefix stripping.
- **Verification**: `test_stage2_b1_b8_regression.py` (8 parser tests).
- **Closed in**: Stage 2

## B9 — Coordinated Deployment Cutover (CLOSED)
- **Affected path**: `packages/drhiro-mcp/src/drhiro_mcp/sse_server.py`
- **Fix**: `DRHIRO_LIQUID_WRITER=legacy|unified` flag (fail-closed).
- **Verification**: `test_stage4_writer_flag.py` (5 tests) + `test_stage4_cutover_rehearsal.py` (5 tests).
- **Closed in**: Stage 4 (this commit)
