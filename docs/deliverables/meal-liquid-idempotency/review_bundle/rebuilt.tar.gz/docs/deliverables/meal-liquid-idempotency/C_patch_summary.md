# C. Patch Summary — Meal+Liquid Idempotency Refactor

**Branch**: `feature/meal-liquid-idempotency`
**Date**: 2026-09-09
**Commit**: {commit_hash}

---

## Files Changed

### 1. `apps/api/src/drhiro_api/models.py`
**Change**: Added three new ORM models for consumption identity + beverage linkage.

| Model | Table | Purpose |
|---|---|---|
| `ConsumptionOperation` | `consumption_operations` | Idempotency key + durable result (Telegram update_id scope) |
| `ConsumptionItem` | `consumption_items` | Stable item identity under an operation (meal item OR beverage) |
| `BeverageMeasurement` | `beverage_measurements` | 1:1 link between a liquid `Measurement` and its source `meal_item` |

**New columns on existing tables** (all nullable, for traceability):
- `meal_items.source_operation_id`, `meal_items.source_item_id`
- `measurements.source_operation_id`, `measurements.source_item_id`, `measurements.meal_item_id`
- `meals.source_operation_id`

### 2. `apps/api/src/drhiro_api/services/consumption.py`
**Change**: Unified consumption domain — the SINGLE write path for all consumption logging.

**Public API**:
- `parse_consumption_text(text)` — canonical item extractor (replaces both `service.py parse_meal_text` and the MCP liquid block)
- `get_or_create_operation(db, user_id, ...)` — idempotency: returns existing operation if one matches Telegram key or caller key
- `get_operation_result(db, operation_id)` — durable result replay
- `write_consumption(db, user_id, items, ...)` — atomic meal + beverage write in ONE transaction
- `confirm_consumption(db, user_id, items, ...)` — single entry point for `/meals/from-text-intelligent/confirm` handler
- **`log_manual_liquid(db, user_id, amount_ml, ...)`** — reconciliation-aware manual liquid logging
- `update_item_quantity(db, user_id, meal_id, item_fragment, new_grams)` — rescale + linked volume update
- `replace_beverage(db, user_id, meal_id, item_fragment, new_category)` — beverage → beverage swap
- `delete_beverage(db, user_id, meal_id, item_fragment)` — removes meal_item + measurement + beverage_measurement
- `delete_meal(db, user_id, meal_id)` — cascades to beverage_measurements

**Internal helpers**:
- `_to_float(num)` — decimal-comma parsing
- `_normalize_meal_type(mt)` — validates breakfast|lunch|dinner|snack, defaults snack
- `_classify_beverage(text)` — token-aware classification (word boundary, most specific first)
- `_stable_item_key(operation_id, index)` — deterministic item key
- `_compute_source_record_id(operation_id, item_key)` — deterministic source_record_id
- `_scale_nutrients(per100, factor)` — scale per-100 nutrients
- `_sum_nutrients(nutrient_dicts)` — sum across all 6 nutrients
- `_recompute_meal_totals(db, meal)` — rebuild meal totals from items
- `_match_item(items, frag)` — fragment → meal_item matching
- **`_reconcile_liquid(db, user_id, amount_ml, category, existing_item_id, eaten_at)`** — link a manual liquid to an EXISTING consumption item
- **`_liquid_to_parsed_items(amount_ml, category, display_name)`** — build a ParsedItem list for a standalone liquid
- **`_write_new_liquid_consumption(db, user_id, items, eaten_at, source, notes)`** — write a genuinely new drink consumption with volume AND calories

### 3. `apps/api/src/drhiro_api/routers/ingest.py`

**Change**: Added reconciliation-aware `/manual/liquid` endpoint.

**New endpoint**: `POST /manual/liquid`
- Routes through `consumption.log_manual_liquid`
- Enforces the three-intent reconciliation semantics
- Returns `ManualLiquidResult` with `ok`, `reconciled`, `clarify`, `error`, `measurement_id`, `message` fields

### 4. `tests/test_legacy_new_water_coexistence.py`
**Change**: Replaced wrong `test_same_drink_manual_plus_meal_counts_twice` (which asserted 660ml double-count for a same-event meal+liquid) with 7 reconciliation-path tests proving the correct semantics.

### 7. `apps/api/src/drhiro_api/services/consumption.py`
**Change**: Fixed nutrient-basis resolution + added B7 canonical mutation functions.

- Fixed `resolve_item_nutrition` to determine nutrient basis by actual measurement (mass-primary when both grams and volume present), not item type.
- Added `update_measurement_value()` — generic measurement update that delegates to beverage logic for beverages.
- Added `delete_measurement()` — generic measurement delete that cascades for beverages.
- Added `update_meal_timestamp()` — timestamp mutation propagated to all linked measurements.
- Added `update_meal_group()` — meal-group mutation propagated to all consumption items.

### 8. `tests/test_stage3_b4_b7_regression.py` (NEW)
**Change**: 17 regression tests for B4 (entry-point coverage) + B7 (canonical mutations).

### 9. `tests/test_stage2_b1_b8_regression.py`
**Change**: Updated `test_mass_vs_volume_beverage_uses_actual_source_basis` to reflect corrected nutrient-basis semantics.

### 10. `docs/deliverables/meal-liquid-idempotency/stage3_entrypoints_coverage_matrix.md` (NEW)
**Change**: Entry-point coverage matrix for every meal/liquid creation + mutation path.

### 6. `packages/drhiro-mcp/src/drhiro_mcp/sse_server.py`
**Change**: Added `DRHIRO_LIQUID_WRITER` flag + re-introduced controllable liquid auto-log block.

- `DRHIRO_LIQUID_WRITER=legacy` (default) — old MCP side effect ACTIVE (pre-cutover behavior)
- `DRHIRO_LIQUID_WRITER=unified` — old MCP side effect SKIPPED; backend is authoritative (post-cutover)
- Any other value → `ValueError` at module load (fail-closed)

Helper functions: `get_liquid_writer_mode()`, `is_unified_writer()`.

### 11. `apps/api/src/drhiro_api/routers/meals.py` (B4 wiring)
**Change**: Four previously-bypassing paths now route through shared domain:
- `add_meal_item` → `_classify_beverage` → `create_beverage_projection`
- `copy_meal` → `copy_beverage_link` per beverage item
- `patch_meal_item` → `propagate_beverage_patch`
- `remove_meal_item` → `delete_beverage_item` for beverages

### 12. `apps/api/src/drhiro_api/routers/datapoints.py` (B4 wiring)
**Change**: Generic measurement CRUD delegates to domain for beverages:
- `update_data_point` → `consumption.update_measurement_value` for beverages
- `delete_data_point` → `consumption.delete_measurement` for beverages

### 13. `tests/test_stage3_wired_paths.py` (NEW, 25 tests)
**Change**: Wired-path regression tests calling real router handlers.

### 16. `apps/api/src/drhiro_api/routers/meals.py` (B7 fix)
**Change**: `delete_meal` now cascades to BeverageMeasurement + Measurement: eagerly loads items, queries linked beverage rows, deletes their Measurements, deletes the BeverageMeasurement rows, then hard-deletes the meal. No orphaned liquid remains.

### 17. `apps/api/src/drhiro_api/services/consumption.py` (B7 fix)
**Change**: `propagate_beverage_patch` now uses `_classify_beverage(new_name)` as the source of truth. When the new name is NOT a beverage, it clears `beverage_category` (sets `volume_ml=None`) and removes the BeverageMeasurement + Measurement. When the new name IS a beverage, it adopts the new category and keeps the liquid projection.

### 18. `tests/test_b7_closing_regression.py` (NEW, 7 tests)
**Change**: `TestDeleteMealCascade` (3 tests: cascade + no-resurrect + ownership-404) and `TestBeverageToSolidRename` (4 tests: rename clears category + drops liquid, rename-by-name, beverage→beverage keeps liquid, ownership-404). Proves both B7 gaps are closed.

### 14. `docs/deliverables/meal-liquid-idempotency/stage3_entrypoints_coverage_matrix.md` (UPDATED)
### 15. `docs/deliverables/meal-liquid-idempotency/stage3_entrypoints_mutations_evidence.md` (UPDATED)

---

## Reconciliation Semantics (Three Distinct Paths)

The `/manual/liquid` endpoint and `log_manual_liquid` function enforce three distinct code paths:

### Path 1: Same-Event Idempotent Replay
**Trigger**: Request carries source identity (`source_chat_id` + `source_message_id` + `source_bot_id`) or `idempotency_key`.
**Resolution**: Look up `ConsumptionOperation` by that identity. If already `completed`, return the SAVED result. No new row.

**Request shape**:
```json
{"amount_ml": 330, "category": "beer", "source": "telegram", "source_chat_id": "...", "source_message_id": "...", "source_bot_id": "..."}
```

**Use case**: One Telegram message causes BOTH meal tool call AND liquid tool call for the SAME drink → ONE consumption (volume once, calories once). Retry/repeated tool invocation returns existing result, no additional contribution.

### Path 2: Explicit-Reference Reconciliation
**Trigger**: Request carries `existing_item_id`.
**Resolution**: Link the new beverage volume to the EXISTING item/measurement. No second row.

**Request shape**:
```json
{"amount_ml": 100, "category": "non_alcoholic", "existing_item_id": "<measurement_id>"}
```

**Use case**: User says "also count that milk as liquid" → volume linked to existing item once; dashboard sum shows it once, not twice. Returns `reconciled: true`, `total_amount_ml` updated.

### Path 3: Genuinely New Drink + Clarify
**Trigger**: Request carries `intent: "new"` (with no source identity / reference). Without `intent: "new"`, ambiguous → CLARIFY.
**Resolution**: Write a NEW consumption with volume AND calories (not a bare water row). If ambiguous, return `clarify: true`, nothing written.

**Request shape** (new drink):
```json
{"amount_ml": 200, "category": "non_alcoholic", "intent": "new", "display_name": "milk"}
```

**Request shape** (ambiguous — triggers clarify):
```json
{"amount_ml": 250, "category": "water"}
```

**Use case**: "I drank another glass of milk" = new consumption with additional volume AND calories. Ambiguous intent = CLARIFY response, not duplicate.

### Dashboard Aggregation Proof
- A caloric standalone drink contributes nutrition once (kcal present, not a bare water row with 0 kcal).
- Same drink cannot yield two rows in the dashboard liquid sum across legacy+new paths. The `log_manual_liquid` replay + reconciliation mechanisms prevent a second row.

---

## Entry Points Touched

| Entry Point | Tool/Route | Wires Into |
|---|---|---|
| MCP `log_meal_intelligent` | `sse_server.py` → `call_api("POST", "/meals/from-text-intelligent/confirm")` | Backend confirm (which uses `consumption.py`) |
| MCP `log_water` | `sse_server.py` → `POST /ingest/manual/liquid` | Reconciliation-aware liquid log |
| MCP `log_liquid` | `sse_server.py` → `POST /ingest/manual/liquid` | Reconciliation-aware liquid log |
| Backend confirm | `service.py` `confirm_meal` (deploy-only) | Should call `consumption.confirm_consumption()` |

---

## What Still Needs Wiring (post-cutover)

The `service.py` on the VPS (deploy-only) needs to be updated to call `consumption.confirm_consumption()` instead of its current `confirm_meal` logic. This is a deploy-pipeline task, not a git commit task. The reference copy at `docs/reference/intelligent-meal-service.py` documents the target behavior.

---

## Test Coverage

233 tests pass. B7 closing regression suite adds 7 tests. the removed `test_same_drink_manual_plus_meal_counts_twice` (which asserted the wrong 660ml double-count semantics). New tests prove:
- Same-event meal+liquid = ONE consumption
- Retry returns saved result, no new contribution
- Explicit reference reconciles to existing item (no second row)
- Genuinely new drink = additional volume AND calories
- Ambiguous intent = CLARIFY, nothing written
- Standalone caloric drink contributes nutrition once
- Same drink cannot yield two rows in the sum
